# todolist_GraphQL_starter
todolist yang digunakan pada video GraphQL 
